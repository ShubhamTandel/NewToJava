package com.EmployeeOnBoardSystem;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDao {

	private static ArrayList<Employee> list = new ArrayList<>();

	public void add_new_Employee(Employee e) {
		list.add(e);
		System.out.println("Employee added");
	}

	public ArrayList<Employee> fetchEmployee() {
		return list;
	}

	public ArrayList<Employee> getByEmNo(long l) {
		return list;
	}

	public void updateEmployee(Employee updatedEmployee) {
		for (int i = 0; i < list.size(); i++) {
			Employee employee = list.get(i);
			if (employee.getEmNo() == updatedEmployee.getEmNo()) {
				list.set(i, updatedEmployee);
				break;
			}
		}
	}

	public void deleteEmployee(long emNo) {
		list.removeIf(employee -> employee.getEmNo() == emNo);
	}

	public List<Employee> getAllEmployees() {
		return new ArrayList<>(list);
	}

	public ArrayList<Employee> getByFName(String name) {
		return list;
	}

	public void updateEmployee1(Employee updatedEmployee) {
		for (int i = 0; i < list.size(); i++) {
			Employee employee = list.get(i);
			if (employee.getE_FName() == updatedEmployee.getE_FName()) {
				list.set(i, updatedEmployee);
				break;
			}
		}
	}

	public void deleteEmployee1(String E_FName) {
		list.removeIf(employee -> employee.getE_FName() == E_FName);
	}

	public ArrayList<Employee> getByE_Email(String mail) {
		return list;
	}

	public void updateEmployee2(Employee updatedEmployee) {
		for (int i = 0; i < list.size(); i++) {
			Employee employee = list.get(i);
			if (employee.getE_Email() == updatedEmployee.getE_Email()) {
				list.set(i, updatedEmployee);
				break;
			}
		}
	}

	public void deleteEmployee2(String E_Email) {
		list.removeIf(employee -> employee.getE_Email() == E_Email);

	}
}