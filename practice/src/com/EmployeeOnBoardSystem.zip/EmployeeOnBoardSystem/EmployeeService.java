package com.EmployeeOnBoardSystem;

import java.util.ArrayList;
import java.util.List;

public class EmployeeService {

    private List<Employee> employees;

    public EmployeeService() {
        // Initialize the list of employees
        employees = new ArrayList<>();
    }

    // Create (Add) operation with validation
    public void addEmployee(Employee employee) {
        if (validateEmployee(employee)) {
            employees.add(employee);
        } else {
            System.out.println("Invalid employee details. Unable to add employee.");
        }
    }

    // Read (Retrieve) operation
    public Employee getEmployeeByEmployeeNumber(long employeeNumber) {
        for (Employee employee : employees) {
            if (employee.getEmNo() == employeeNumber) {
                return employee;
            }
        }
        return null; // Employee not found
    }

    // Update operation with validation
    public void updateEmployee(Employee updatedEmployee) {
        if (validateEmployee(updatedEmployee)) {
            for (int i = 0; i < employees.size(); i++) {
                Employee employee = employees.get(i);
                if (employee.getEmNo() == updatedEmployee.getEmNo()) {
                    employees.set(i, updatedEmployee);
                    break;
                }
            }
        } else {
            System.out.println("Invalid employee details. Unable to update employee.");
        }
    }

    // Delete operation
    public void deleteEmployee(long emNo) {
        employees.removeIf(employee -> employee.getEmNo() == emNo);
    }

    // Read all employees
    public List<Employee> getAllEmployees() {
        return new ArrayList<>(employees); // Return a copy to avoid modifying the original list
    }

    // Validate employee details
    private boolean validateEmployee(Employee employee) {
        // Add your validation logic here
        if (employee == null || employee.getEmNo() <= 0 || employee.getE_Salary() < 0) {
            return false;
        }
        // Add more validation as needed
        return true;
    }
}
