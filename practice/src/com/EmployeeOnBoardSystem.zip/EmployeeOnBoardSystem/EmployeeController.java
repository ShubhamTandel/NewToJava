package com.EmployeeOnBoardSystem;

import java.util.List;
import java.util.Scanner;

public class EmployeeController {

    private EmployeeService employeeService;
    private Scanner scanner;

    public EmployeeController() {
        this.employeeService = new EmployeeService();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        int choice;
        do {
            System.out.println("1. Add Employee");
            System.out.println("2. Update Employee");
            System.out.println("3. Delete Employee");
            System.out.println("4. View Employee Details");
            System.out.println("5. View All Employees");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    updateEmployee();
                    break;
                case 3:
                    deleteEmployee();
                    break;
                case 4:
                    viewEmployeeDetails();
                    break;
                case 5:
                    viewAllEmployees();
                    break;
                case 0:
                    System.out.println("Exiting the Employee System. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 0);
    }

    private void addEmployee() {
        System.out.println("Enter employee details:");
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Employee Number: ");
        long employeeNumber = scanner.nextLong();
        System.out.print("Salary: ");
        double salary = scanner.nextDouble();
        // You can add more input validations if needed

        Employee employee = new Employee(firstName, lastName, employeeNumber, salary, "", 0, "", null);
        employeeService.addEmployee(employee);
        System.out.println("Employee added successfully!");
    }

    private void updateEmployee() {
        System.out.print("Enter employee number to update: ");
        long employeeNumber = scanner.nextLong();
        Employee existingEmployee = employeeService.getEmployeeByEmployeeNumber(employeeNumber);
        if (existingEmployee != null) {
            System.out.println("Enter updated employee details:");
            System.out.print("First Name: ");
            String firstName = scanner.nextLine();
            System.out.print("Last Name: ");
            String lastName = scanner.nextLine();
            System.out.print("Salary: ");
            double salary = scanner.nextDouble();
            // You can add more input validations if needed

            Employee updatedEmployee = new Employee(firstName, lastName, employeeNumber, salary, "", 0, "", null);
            employeeService.updateEmployee(updatedEmployee);
            System.out.println("Employee updated successfully!");
        } else {
            System.out.println("Employee not found!");
        }
    }

    private void deleteEmployee() {
        System.out.print("Enter employee number to delete: ");
        long employeeNumber = scanner.nextLong();
        employeeService.deleteEmployee(employeeNumber);
        System.out.println("Employee deleted successfully!");
    }

    private void viewEmployeeDetails() {
        System.out.print("Enter employee number to view details: ");
        long employeeNumber = scanner.nextLong();
        Employee employee = employeeService.getEmployeeByEmployeeNumber(employeeNumber);
        if (employee != null) {
            System.out.println("Employee Details:\n" + employee);
        } else {
            System.out.println("Employee not found!");
        }
    }

    private void viewAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            System.out.println("All Employees:");
            for (Employee employee : employees) {
                System.out.println(employee);
            }
        }
    }

    public static void main(String[] args) {
        EmployeeController employeeController = new EmployeeController();
        employeeController.start();
    }
}
