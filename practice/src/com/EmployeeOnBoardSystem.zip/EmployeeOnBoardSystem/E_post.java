package com.EmployeeOnBoardSystem;

public enum E_post {
	Intern,
	F_Developer,
	B_Developer,
	HR,
	ProductLead,
	Designer,
	Customer_Support,
	SEO
	
	
	
}
